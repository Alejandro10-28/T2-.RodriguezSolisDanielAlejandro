﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Error_Debug1
{
   public class Estudiante
    {
       //Se encapsulan los atributos 
        public string Nombre { get; set; }
        public string Carrera { get; set; }
        public int Semestre { get; set; }
        public int Telefono { get; set; }
        public int NoControl { get; set; }
    }
}
